<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Audit */

$this->title = $model->ID;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Audits'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="audit-view">
    <h1><?= Html::encode($this->title) ?></h1>
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'ID',
            'BATCH_ID',
            'DSI',
            'SOURCE',
            'TARGET',
            'INSTITUTION',
            'INTEGRATION',
            'SERVICE',
            'ENDPOINT_URL:url',
            'STATUS',
            'ERROR_CODE',
            'REASON',
            'RETRY_COUNT',
            'MSG_ID',
            'RETRY_COUNT_EMAIL:email',
            'RETRY_TS',
            'CREATED_TS',
        ],
    ]) ?>

</div>
