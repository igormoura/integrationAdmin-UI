<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use dosamigos\ckeditor\CKEditor;

/* @var $this yii\web\View */
/* @var $model app\models\Audit */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="audit-form">
    <?php $form = ActiveForm::begin(['action' => ['payload'], 'id' => 'update-payload', 'method' => 'post']); ?>
      <?= $form->field($model, 'ID')->hiddenInput(['id'=>'audit-id'])->label(false); ?>
      <?= $form->field($model, 'PAYLOAD')->textarea(['rows' => '15', 'maxlength' => true]) ?>
    <?php ActiveForm::end(); ?>
</div>
