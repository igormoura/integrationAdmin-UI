
<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\daterange\DateRangePicker;
use kartik\select2\Select2;
use kartik\dialog\Dialog;
use yii\widgets\Pjax;
use nirvana\showloading\ShowLoadingAsset;

ShowLoadingAsset::register($this);

/* @var $this yii\web\View */
/* @var $searchModel app\models\searchs\Audit */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Audit View');
$this->params['breadcrumbs'][] = $this->title;
?>
<?php Pjax::begin(['id' => 'pjax-grid-view']); ?>
<div class="audit-index">
  <h1><?= Html::encode($this->title) ?></h1>
  <?= Html::beginForm(['resubmit-now'],'post', ['id'=>'resubmit-now']);?>
  <?= GridView::widget([
      'dataProvider' => $dataProvider,
      'filterModel' => $searchModel,
      'columns' => [
          ['class' => 'yii\grid\SerialColumn'],
          [
            'class' => 'yii\grid\CheckboxColumn', 'checkboxOptions' => function($model) {
                  return ['value' => $model->ID];
            },
          ],
          [
            'label' => Yii::t('app', "Institutions"),
            'attribute' => 'INSTITUTION',
            'filter' => Select2::widget([
                  'model' => $searchModel,
                  'attribute' => 'INSTITUTION',
                  'theme' => Select2::THEME_BOOTSTRAP,
                  'data' =>  $institutions,
                  'options' => ['multiple' => true, 'placeholder' => 'Select institution ...'],
                  'pluginOptions' => [
                      'allowClear' => true
                  ],
              ]),
            'contentOptions' => ['style' => 'width:200px;  min-width:200px;'],
          ],
          [
            'label' => Yii::t('app', "Institution ID"),
            'attribute' => 'DSI'
          ],
          'INTEGRATION',
          [
            'label' => Yii::t('app', "Message ID"),
            'attribute' => 'MSG_ID',
          ],
          'SOURCE',
          'TARGET',
          'ERROR_CODE',
          [
            'label' => Yii::t('app', "Status"),
            'attribute' => 'STATUS',
            'content'=> function($data){
              switch ($data->STATUS) {
                case 'C':
                  return '<span class="label label-success">Success</span>';
                  break;
                case 'R':
                  return '<span class="label label-warning">Retry</span>';
                  break;
                case 'E':
                  return '<span class="label label-danger">Error</span>';
                  break;
                case 'S':
                  return '<span class="label label-primary">Start</span>';
                  break;
                default:
                  return '';
                  break;
              }
            },
            'filter' => Select2::widget([
                  'model' => $searchModel,
                  'attribute' => 'STATUS',
                  'theme' => Select2::THEME_BOOTSTRAP,
                  'data' =>  ['C'=> 'Success', 'R'=>'Retry', 'E'=>'Error', 'S' => 'Start'],
                  'options' => ['multiple' => false, 'placeholder' => 'Select status'],
                  'pluginOptions' => [
                      'allowClear' => true
                  ],
              ]),
            'contentOptions' => ['style' => 'width:100px;  min-width:100px;'],
          ],
          [
            'label' => Yii::t('app', "Created at"),
            'attribute' => 'CREATED_TS',
            'format' => 'datetime',
            'filter' => DateRangePicker::widget([
                'model' => $searchModel,
                'attribute'=>'CREATED_TS',
                'convertFormat' => true,
                'presetDropdown'=>true,
                'pluginOptions'=>[
                    'timePicker'=>true,
                    'timePicker24Hour' => true,
                    'locale'=>['format'=>'Y/m/d H:i:s'],
                ]
            ]),
          ],
          [
            'class' => 'yii\grid\ActionColumn',
            'header' => 'Actions',
            'headerOptions' => ['style' => 'color:#337ab7'],
            'template' => '{view}{update-payload}',
            'contentOptions' => ['style' => 'width:30px;  min-width:30px;'],
            'buttons' => [
              'view' => function ($url, $model) {
                  return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', '/audit/view/'.$model->ID, [
                              'title' => Yii::t('app', 'View'),
                  ]);
              },
              'update-payload' => function ($url, $model) {
                  return Html::a('<span class="glyphicon glyphicon-tasks"></span>', '#', [
                              'class' => 'activity-view-link',
                              'title' => Yii::t('app', 'Update Payload'),
                              'data-toggle' => 'modal',
                              'data-target' => '#updatePayload',
                              'data-id' => $model->ID,
                              'data-pjax' => '0',
                  ]);
              },
            ],
          ],
      ],
  ]); ?>
  <?= Html::button('<span class="glyphicon glyphicon-retweet" aria-hidden="true"></span> Resubmit now', ['class' => 'btn btn-success', 'id'=>'btn-confirm', 'disabled'=>'disabled']) ?>
  <?= Html::endForm();?>
</div>

<!-- Modal Update Payload, save and resubmit -->
<div class="modal fade" id="updatePayload" tabindex="-1" role="dialog" aria-labelledby="updatePayloadLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Audit details - Payload</h4>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-close-modal" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-resubmit-now">Resubmit now</button>
      </div>
    </div>
  </div>
</div>

<!-- Open modal to edit payload -->
<?php $this->registerJs(
    "$('.activity-view-link').click(function() {
      var audit_id = $(this).closest('tr').data('key');
      var modal_body=$('#updatePayload').find('.modal-body');
      $.ajax({
          url:'payload',
          data:{'id':audit_id},
          success:function(res){
            modal_body.html(res);
          }
      });
     })"
); ?>

<!-- Resubmit audit detail of modal -->
<?php $this->registerJs(
    "$('.btn-resubmit-now').click(function() {
      var form = $('form#update-payload');
      var audit_id = $('#audit-id').val();
      $('#updatePayload').modal('toggle');
      $('.audit-index').showLoading();
      $.ajax({
          type: 'post',
          url:'resubmitnow',
          data: form.serialize(),
          success:function(res){
              $('.audit-index').hideLoading();

              $.notify({
                title: '<strong>Success</strong><br>',
                message: 'Resubmit with successful',
              },{
                type: 'success',
                animate: {
                  enter: 'animated fadeInDown',
                  exit: 'animated fadeOutUp'
                }
              });

              console.log('Response: ',res);
             $('#updatePayload').modal('hide');
          },
          error: function(res){
            $('.audit-index').hideLoading();

            $.notify({
              title: '<strong>Error</strong><br>',
              message: res.status + ' - ' + res.statusText,
            },{
              type: 'danger',
              animate: {
                enter: 'animated fadeInDown',
                exit: 'animated fadeOutUp'
              }
            });

            console.log('Response error: ',res.responseText);
          }
      });
     })"
); ?>

<!-- Close modal and clear textarea -->
<?php $this->registerJs(
    "$('.btn-close-modal').click(function() {
      $('#updatePayload').find('.modal-body').html('');
     })"
); ?>

<!-- DELETE selected in BULK -->
<?php echo
  Dialog::widget([
     'libName' => 'builkresubmitnow',
     'options' => [
       'title' => 'Resubmit now',
       'closable' => true,
       'type' => Dialog::TYPE_SUCCESS,
       'btnOKClass' => 'btn-success',
     ], // custom options
  ]);

  $this->registerJs(
    '$("#btn-confirm").on("click", function() {
        builkresubmitnow.confirm("Confirm resubmit now of the selected items?", function (result) {
            if (result) {
                var form = $("form#resubmit-now");
                $(".audit-index").showLoading();
                $.ajax({
                      url    : "builkresubmitnow",
                      type   : "POST",
                      data   : form.serialize(),
                      delay  : 5000,
                      success: function (response)
                      {
                         $(".audit-index").hideLoading();
                         console.log(response);
                         $.pjax({container: "#pjax-grid-view"});
                         $.notify({
                           title: "<strong>Successful</strong><br>",
                           message: "Resubmit with successful",
                         },{
                           type: "success",
                           animate: {
                             enter: "animated fadeInDown",
                             exit: "animated fadeOutUp"
                           }
                         });
                      },
                      error  : function (e)
                      {
                          $(".audit-index").hideLoading();
                          console.log(e);
                          $.pjax({container: "#pjax-grid-view"});
                          $.notify({
                          	title: "<strong>Error</strong><br>",
                          	message: e.status + " - " + e.statusText,
                          },{
                          	type: "danger",
                          	animate: {
                          		enter: "animated fadeInDown",
                          		exit: "animated fadeOutUp"
                          	}
                          });
                      }
                  });
            }
        });
    });'
  );
?>

<!-- Check if ENABLE or DISABLED buttons -->
<?php echo
  $this->registerJs('
    $(":checkbox").change(function() {
        if($(\'[name="selection[]"]:checked\').length > 0){
          $("#btn-confirm").prop("disabled", false);
        }else{
          $("#btn-confirm").prop("disabled", true);
        }
    });
  ');
?>

<!-- Substring Date range CREATED_TS -->
<?php echo
  $this->registerJs('
    datatimeToDate();
    $( "#audit-created_ts-container" ).change(function() {
      datatimeToDate();
    });
    function datatimeToDate() {
      var elem = $("#audit-created_ts-container span.range-value");
      elem.text(elem.text().substring(0, 10)+\' - \'+elem.text().substring(22, 32));
    }
  ');
?>

<?php Pjax::end(); ?>
