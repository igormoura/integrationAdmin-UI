<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Sequence */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Sequence',
]) . $model->NAME;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Sequences'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->NAME, 'url' => ['view', 'id' => $model->NAME]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="sequence-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
