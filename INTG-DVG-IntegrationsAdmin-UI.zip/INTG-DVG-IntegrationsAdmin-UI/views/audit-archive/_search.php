<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\searchs\AuditArchive */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="audit-archive-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
        'options' => [
            'data-pjax' => 1
        ],
    ]); ?>

    <?= $form->field($model, 'ID') ?>

    <?= $form->field($model, 'BATCH_ID') ?>

    <?= $form->field($model, 'DSI') ?>

    <?= $form->field($model, 'SOURCE') ?>

    <?= $form->field($model, 'TARGET') ?>

    <?php // echo $form->field($model, 'INSTITUTION') ?>

    <?php // echo $form->field($model, 'INTEGRATION') ?>

    <?php // echo $form->field($model, 'SERVICE') ?>

    <?php // echo $form->field($model, 'ENDPOINT_URL') ?>

    <?php // echo $form->field($model, 'STATUS') ?>

    <?php // echo $form->field($model, 'ERROR_CODE') ?>

    <?php // echo $form->field($model, 'REASON') ?>

    <?php // echo $form->field($model, 'RETRY_COUNT') ?>

    <?php // echo $form->field($model, 'MSG_ID') ?>

    <?php // echo $form->field($model, 'RETRY_COUNT_EMAIL') ?>

    <?php // echo $form->field($model, 'RETRY_TS') ?>

    <?php // echo $form->field($model, 'CREATED_TS') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
