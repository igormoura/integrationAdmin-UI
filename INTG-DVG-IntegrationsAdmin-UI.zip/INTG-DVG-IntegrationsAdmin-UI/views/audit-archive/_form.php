<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\AuditArchive */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="audit-archive-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'BATCH_ID')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'DSI')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'SOURCE')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'TARGET')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'INSTITUTION')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'INTEGRATION')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'SERVICE')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'ENDPOINT_URL')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'STATUS')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'ERROR_CODE')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'REASON')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'RETRY_COUNT')->textInput() ?>

    <?= $form->field($model, 'MSG_ID')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'RETRY_COUNT_EMAIL')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'RETRY_TS')->textInput() ?>

    <?= $form->field($model, 'CREATED_TS')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
