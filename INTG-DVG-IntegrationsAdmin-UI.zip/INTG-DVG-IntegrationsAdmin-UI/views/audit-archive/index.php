<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\daterange\DateRangePicker;
use kartik\select2\Select2;
use kartik\dialog\Dialog;

/* @var $this yii\web\View */
/* @var $searchModel app\models\searchs\Audit */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Audits Archive');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="audit-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <?= Html::beginForm(['resubmit-now'],'post', ['id'=>'resubmit-now']);?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
              'class' => 'yii\grid\CheckboxColumn', 'checkboxOptions' => function($model) {
                    return ['value' => $model->ID];
              },
            ],
            [
              'label' => Yii::t('app', "Institutions"),
              'attribute' => 'INSTITUTION',
              'filter' => Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'INSTITUTION',
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'data' =>  $institutions,
                    'options' => ['multiple' => true, 'placeholder' => 'Select institution ...'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ]),
              'contentOptions' => ['style' => 'width:200px;  min-width:200px;'],
            ],
            'INTEGRATION',
            [
              'label' => Yii::t('app', "Message ID"),
              'attribute' => 'MSG_ID',
            ],
            'SOURCE',
            'TARGET',
            'ERROR_CODE',
            [
              'label' => Yii::t('app', "Status"),
              'attribute' => 'STATUS',
              'content'=> function($data){
                switch ($data->STATUS) {
                  case 'C':
                    return '<span class="label label-success">Success</span>';
                    break;
                  case 'R':
                    return '<span class="label label-warning">Retry</span>';
                    break;
                  case 'E':
                    return '<span class="label label-danger">Error</span>';
                    break;
                  default:
                    return '';
                    break;
                }
              },
              'filter' => Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'STATUS',
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'data' =>  ['C'=> 'Success', 'R'=>'Retry', 'E'=>'Error'],
                    'options' => ['multiple' => false, 'placeholder' => 'Select status'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ]),
              'contentOptions' => ['style' => 'width:100px;  min-width:100px;'],
            ],
            [
              'label' => Yii::t('app', "Created at"),
              'attribute' => 'CREATED_TS',
              'format' => 'date',
              'filter' => DateRangePicker::widget([
                  'model' => $searchModel,
                  'value' => '',
                  'attribute'=>'CREATED_TS',
                  'convertFormat' => true,
                  'presetDropdown'=>true,
                  'pluginOptions'=>[
                      'locale'=>['format'=>'Y/m/d'],
                  ]
              ]),
              'contentOptions' => ['style' => 'width:230px;  min-width:230px;'],
            ],
            [
              'class' => 'yii\grid\ActionColumn',
              'header' => 'Actions',
              'headerOptions' => ['style' => 'color:#337ab7'],
              'template' => '{view}{send-current-database}',
              'contentOptions' => ['style' => 'width:30px;  min-width:30px;'],
              'buttons' => [
                'view' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', '/audit-archive/view?id='.$model->ID, [
                                'title' => Yii::t('app', 'View'),
                    ]);
                },
                'send-current-database' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-export"></span>', '#', [
                                'class' => 'send-current-database',
                                'title' => Yii::t('app', 'Update Payload'),
                                'data-id' => $model->ID,
                                'data-pjax' => '0',
                    ]);
                },
              ],
            ],
        ],
    ]); ?>
    <?= Html::button('<span class="glyphicon glyphicon-export" aria-hidden="true"></span> Send current database', ['class' => 'btn btn-success', 'id'=>'btn-confirm', 'disabled'=>'disabled']) ?>
    <?= Html::endForm();?>
</div>

<!-- Resubmit now audit detail -->
<?php echo
  Dialog::widget([
     'libName' => 'sendToCurrentDatabase',
     'options' => [
       'title' => 'Send to current database',
       'closable' => true,
       'type' => Dialog::TYPE_SUCCESS,
       'btnOKClass' => 'btn-success',
     ], // custom options
  ]);

  $this->registerJs(
    '$(".send-current-database").on("click", function() {
        var tr = $(this);
        sendToCurrentDatabase.confirm("Confirms sending to current database?", function (result) {
            if (result) {
              $.ajax({
                  url:"sendcurrentdatabase",
                  data:{"id":tr.context.dataset.id},
                  success:function(res){
                    console.log(res);
                  }
              });
            }
        });
    });'
   );
?>

<!-- SEND DATABASE selected in BULK -->
<?php echo
  Dialog::widget([
     'libName' => 'krajeeDialog',
     'options' => [
       'title' => 'Send to current database',
       'closable' => true,
       'type' => Dialog::TYPE_SUCCESS,
       'btnOKClass' => 'btn-success',
     ],
  ]);

  $this->registerJs(
    '$("#btn-confirm").on("click", function() {
        krajeeDialog.confirm("Confirm resubmit now of the selected items?", function (result) {
            if (result) {
                var form = $("form#resubmit-now");
                $.ajax({
                      url    : "bulk",
                      type   : "POST",
                      data   : form.serialize(),
                      success: function (response)
                      {
                         console.log(response);
                      },
                      error  : function (e)
                      {
                          console.log(e);
                      }
                  });
            }
        });
    });'
  );
?>

<!-- VALIDATE IF EXIST ITEM SELECTED -->
<?php echo
  $this->registerJs('
    $(":checkbox").change(function() {
        if($(\'[name="selection[]"]:checked\').length > 0){
          $("#btn-confirm").prop("disabled", false);
        }else{
          $("#btn-confirm").prop("disabled", true);
        }
    });
  ');
?>
