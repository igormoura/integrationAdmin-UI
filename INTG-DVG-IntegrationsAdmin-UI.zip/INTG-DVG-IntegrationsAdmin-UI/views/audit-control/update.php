<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Integration */

$this->title = Yii::t('app', 'Update {modelClass}: ', [
    'modelClass' => 'Audit Control',
]) . $model->INSTITUTION;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Audit Control'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->INSTITUTION, 'url' => ['view', 'INSTITUTION' => $model->INSTITUTION, 'INTEGRATION' => $model->INTEGRATION]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="integration-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'institutions' => $institutions,
    ]) ?>

</div>
