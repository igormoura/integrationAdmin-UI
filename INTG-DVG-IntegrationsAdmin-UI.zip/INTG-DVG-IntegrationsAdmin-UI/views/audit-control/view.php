<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Integration */

$this->title = $model->INSTITUTION;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Audit Control'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="integration-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a(Yii::t('app', 'Update'), ['update', 'INSTITUTION' => $model->INSTITUTION, 'INTEGRATION' => $model->INTEGRATION], ['class' => 'btn btn-primary']) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'INSTITUTION',
            'INTEGRATION',
            'FIRST_OR_LAST',
            'REPROCESS',
            'CREATED_BY',
            'CREATED_TS',
        ],
    ]) ?>

</div>
