<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Integration */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="integration-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
      <div class="col-md-6">
        <?= $form->field($model, 'INSTITUTION')->dropDownList($institutions); ?>
      </div>
      <div class="col-md-6">
        <?= $form->field($model, 'INTEGRATION')->textInput(['maxlength' => true]) ?>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <?= $form->field($model, 'FIRST_OR_LAST')->textInput(['maxlength' => true]) ?>
      </div>
      <div class="col-md-6">
        <?= $form->field($model, 'REPROCESS')->dropDownList(['Y'=>'YES','N'=>'NO']); ?>
      </div>
    </div>

    <div class="form-group">
        <?= Html::a(Yii::t('app', 'Cancel'), ['index'], ['class' => 'btn btn-default']) ?>
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
