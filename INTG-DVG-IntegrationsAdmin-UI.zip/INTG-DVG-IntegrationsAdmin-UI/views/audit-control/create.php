<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Integration */

$this->title = Yii::t('app', 'Create Audit Control');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Integrations'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="integration-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'institutions' => $institutions,
    ]) ?>

</div>
