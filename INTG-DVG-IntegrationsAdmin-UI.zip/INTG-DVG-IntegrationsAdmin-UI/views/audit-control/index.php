<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\daterange\DateRangePicker;
use kartik\select2\Select2;
use kartik\dialog\Dialog;
use yii\widgets\Pjax;
use yii\widgets\LinkPager;
use app\models\CustomPagination;

/* @var $this yii\web\View */
/* @var $searchModel app\models\searchs\Integration */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Audit Control');
$this->params['breadcrumbs'][] = $this->title;
?>
<?php Pjax::begin(['id' => 'pjax-grid-view']); ?>
<div class="integration-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <?= Html::beginForm(['reprocess'],'post', ['id'=>'reprocess']);?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
              'class' => 'yii\grid\CheckboxColumn', 'checkboxOptions' => function($model) {
                    return ['value' => $model->INTEGRATION];
              },
            ],
            [
              'label' => Yii::t('app', "Reprocess"),
              'attribute' => 'REPROCESS',
              'content'=> function($data){
                return $data->REPROCESS == 'Y' ? '<span class="label label-success">Enable</span>' : '<span class="label label-danger">Disable</span>';
              },
              'filter' => Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'REPROCESS',
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'data' =>  ['Y'=> 'Enable', 'N'=>'Disable'],
                    'options' => ['multiple' => false, 'placeholder' => ''],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ]),
              'contentOptions' => ['style' => 'width:100px;  min-width:100px;'],
            ],
            [
              'label' => Yii::t('app', "Institutions"),
              'attribute' => 'INSTITUTION',
              'filter' => Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'INSTITUTION',
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'data' =>  $institutions,
                    'options' => ['multiple' => true, 'placeholder' => 'Select institution ...'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ]),
              'contentOptions' => ['style' => 'width:200px;  min-width:200px;'],
            ],
            'INTEGRATION',
            'CREATED_BY',
            [
              'label' => Yii::t('app', "Created at"),
              'attribute' => 'CREATED_TS',
              'format' => 'date',
              'filter' => DateRangePicker::widget([
                  'model' => $searchModel,
                  'value' => '',
                  'attribute'=>'CREATED_TS',
                  'convertFormat' => true,
                  'presetDropdown'=>true,
                  'pluginOptions'=>[
                      'locale'=>['format'=>'Y/m/d'],
                  ]
              ]),
              'contentOptions' => ['style' => 'width:230px;  min-width:230px;'],
            ],
            [
              'class' => 'yii\grid\ActionColumn',
              'header' => 'Actions',
              'headerOptions' => ['style' => 'color:#337ab7'],
              'template' => '{view}{update}{reprocess}',
              'contentOptions' => ['style' => 'width:30px;  min-width:30px;'],
              'buttons' => [
                'view' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', '/audit-control/view?INSTITUTION='.$model->INSTITUTION.'&INTEGRATION='.$model->INTEGRATION, [
                                'title' => Yii::t('app', 'View'),
                    ]);
                },
                'update' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-pencil"></span>', '/audit-control/update?INSTITUTION='.$model->INSTITUTION.'&INTEGRATION='.$model->INTEGRATION, [
                                'title' => Yii::t('app', 'View'),
                    ]);
                },
                'reprocess' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-refresh"></span>', '#', [
                                'class' => 'btn-reprocess',
                                'title' => Yii::t('app', 'Reprocess'),
                                'data-pjax' => '0',
                    ]);
                },
              ],
            ],
        ],
    ]); ?>
    <?= Html::button('<span class="glyphicon glyphicon-ban-circle" aria-hidden="true"></span>  Disable Reprocess', ['class' => 'btn btn-danger btn-confirm', 'id'=>'btn-disable', 'disabled'=>'disabled']) ?>
    <?= Html::button('<span class="glyphicon glyphicon-ok" aria-hidden="true"></span>  Enable Reprocess', ['class' => 'btn btn-success btn-confirm', 'id'=>'btn-enable', 'disabled'=>'disabled']) ?>
    <?= Html::a(Yii::t('app', 'Create Audit Control'), ['create'], ['class' => 'btn btn-primary']) ?>
    <?= Html::endForm();?>
</div>

<!-- Reprocess row seletected -->
<?php echo
  Dialog::widget([
     'libName' => 'reprocess',
     'options' => [
       'title' => 'Reprocess',
       'closable' => true,
       'type' => Dialog::TYPE_SUCCESS,
       'btnOKClass' => 'btn-success',
     ], // custom options
  ]);

  $this->registerJs(
    '$(".btn-reprocess").on("click", function() {
        var obj = $(this).closest("tr").data("key");
        reprocess.confirm("Confirm reprocess?", function (result) {
            if (result) {
              $.ajax({
                  method: "POST",
                  url:"reprocess",
                  data:{"INSTITUTION": obj.INSTITUTION, "INTEGRATION":obj.INTEGRATION},
                  success:function(res){
                    console.log(res);
                    $.pjax({container: "#pjax-grid-view"});
                    $.notify({
                      message: "Reprocess changed with successfully.",
                    },{
                      type: "success",
                      animate: {
                        enter: "animated fadeInDown",
                        exit: "animated fadeOutUp"
                      }
                    });
                  },
                  error:function(res){
                    console.log(res);
                    $.pjax({container: "#pjax-grid-view"});
                    $.notify({
                      title: "<strong>Successful</strong><br>",
                      message: e.status + " - " + e.statusText,
                    },{
                      type: "danger",
                      animate: {
                        enter: "animated fadeInDown",
                        exit: "animated fadeOutUp"
                      }
                    });
                  }
              });
            }
        });
    });'
   );
?>

<!-- ENABLE REPROCESS selected in BULK -->
<?php echo
  Dialog::widget([
     'libName' => 'enableReprocess',
     'options' => [
       'title' => 'Enable Reprocess',
       'closable' => true,
       'type' => Dialog::TYPE_SUCCESS,
       'btnOKClass' => 'btn-success',
     ],
  ]);

  $this->registerJs(
    '$("#btn-enable").on("click", function() {
        enableReprocess.confirm("Confirm enable reprocess now of the selected items?", function (result) {
            if (result) {
                var form = $("form#reprocess");
                $.ajax({
                      url    : "enablereprocessbulk",
                      type   : "POST",
                      data   : form.serialize(),
                      success: function (response)
                      {
                         console.log(response);
                      },
                      error  : function (e)
                      {
                          console.log(e);
                      }
                  });
            }
        });
    });'
  );
?>

<!-- DISABLE REPROCESS selected in BULK -->
<?php echo
  Dialog::widget([
     'libName' => 'disableReprocess',
     'options' => [
       'title' => 'Disable Reprocess',
       'closable' => true,
       'type' => Dialog::TYPE_DANGER,
       'btnOKClass' => 'btn-danger',
     ],
  ]);

  $this->registerJs(
    '$("#btn-disable").on("click", function() {
        disableReprocess.confirm("Confirm disable reprocess now of the selected items?", function (result) {
            if (result) {
                var form = $("form#reprocess");
                $.ajax({
                      url    : "disablereprocessbulk",
                      type   : "POST",
                      data   : form.serialize(),
                      success: function (response)
                      {
                         console.log(response);
                      },
                      error  : function (e)
                      {
                          console.log(e);
                      }
                  });
            }
        });
    });'
  );
?>

<!-- VALIDATE IF EXIST ITEM SELECTED -->
<?php echo
  $this->registerJs('
    $(":checkbox").change(function() {
        if($(\'[name="selection[]"]:checked\').length > 0){
          $(".btn-confirm").prop("disabled", false);
        }else{
          $(".btn-confirm").prop("disabled", true);
        }
    });
  ');
?>

<?php Pjax::end(); ?>
