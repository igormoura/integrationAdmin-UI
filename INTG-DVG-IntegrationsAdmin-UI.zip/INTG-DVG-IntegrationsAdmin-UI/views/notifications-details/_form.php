<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use dosamigos\ckeditor\CKEditor;
use yii\bootstrap\Dropdown;

/* @var $this yii\web\View */
/* @var $model app\models\DvgNotificationsDetails */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="dvg-notifications-details-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
      <div class="col-md-6">
        <?= $form->field($model, 'process_code')->textInput(['maxlength' => true]) ?>
      </div>
      <div class="col-md-6">
        <?= $form->field($model, 'event_code')->textInput(['maxlength' => true]) ?>
      </div>
    </div>

    <?= $form->field($model, 'institution')->dropDownList($institutions); ?>

    <div class="row">
      <div class="col-md-6">
        <?= $form->field($model, 'mail_list')->textInput(['maxlength' => true]) ?>
      </div>
      <div class="col-md-6">
        <?= $form->field($model, 'from_list')->textInput(['maxlength' => true]) ?>
      </div>
    </div>

    <?= $form->field($model, 'event_desc')->textarea(['rows' => '4']) ?>

    <div class="form-group">
        <?= Html::a(Yii::t('app', 'Cancel'), ['index'], ['class' => 'btn btn-default']) ?>
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
