<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use kartik\date\DatePicker;

/* @var $this yii\web\View */
/* @var $model app\models\searchs\DvgNotificationsDetails */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="dvg-notifications-details-search form-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <div class="row">
      <div class="col-md-4">
        <?= $form->field($model, 'institution')->widget(Select2::classname(), [
            'data' => $institutions,
            'language' => 'en',
            'options' => ['multiple' => true, 'placeholder' => 'Select institutions ...'],
            'pluginOptions' => [
                'allowClear' => true
            ],
        ]);?>
      </div>

      <div class="col-md-4">
        <?= $form->field($model, 'process_code') ?>
      </div>

      <div class="col-md-4">
        <?= $form->field($model, 'event_code') ?>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4">
        <?= $form->field($model, 'createdByName') ?>
      </div>

      <div class="col-md-4">
        <?= $form->field($model, 'updatedByName') ?>
      </div>

      <div class="col-md-4">
        <?= $form->field($model, 'updated_at')->widget(DatePicker::classname(), [
            'options' => ['placeholder' => 'Select date updated at'],
            'pluginOptions' => [
                'autoclose'=>true,
                'format' => 'yyyy-m-dd',
            ]]);?>
      </div>
    </div>


    <?php // echo $form->field($model, 'from_list') ?>

    <?php // echo $form->field($model, 'institution') ?>

    <?php // echo $form->field($model, 'created_by') ?>

    <?php // echo $form->field($model, 'updated_by') ?>

    <?php // echo $form->field($model, 'created_at') ?>

    <?php // echo $form->field($model, 'updated_at') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
