<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\DvgNotificationsDetails */

$this->title = Yii::t('app', 'Create Dvg Notifications Details');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Dvg Notifications Details'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="dvg-notifications-details-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'institutions' => $institutions
    ]) ?>
    
</div>
