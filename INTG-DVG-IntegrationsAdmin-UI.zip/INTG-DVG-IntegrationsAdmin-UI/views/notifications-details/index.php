<?php

use yii\helpers\Html;
use yii\grid\GridView;
use mickgeek\actionbar\Widget as ActionBar;
use kartik\daterange\DateRangePicker;
use kartik\select2\Select2;
use kartik\dialog\Dialog;

/* @var $this yii\web\View */
/* @var $searchModel app\models\searchs\DvgNotificationsDetails */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Notifications Details');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="dvg-notifications-details-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <?= Html::beginForm(['bulk'],'post', ['id'=>'bulk-del']);?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel'  => $searchModel,
        'columns'      => [
            ['class' => 'yii\grid\SerialColumn'],
            [
              'class' => 'yii\grid\CheckboxColumn', 'checkboxOptions' => function($model) {
                    return ['value' => $model->id];
              },
            ],
            [
              'label' => Yii::t('app', "Institutions"),
              'attribute' => 'institution',
              'filter' => Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'institution',
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'data' =>  $institutions,
                    'language' => 'en',
                    'options' => ['multiple' => true, 'placeholder' => 'Select institution ...'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ]),
              'contentOptions' => ['style' => 'width:200px;  min-width:200px;'],
            ],
            'process_code',
            'event_code',
            'from_list',
            'mail_list',
            'created_by',
            'updated_by',
            [
              'label' => Yii::t('app', "Update at"),
              'attribute' => 'updated_at',
              'format' => 'date',
              'filter' => DateRangePicker::widget([
                  'model' => $searchModel,
                  'attribute'=>'updated_at',
                  'convertFormat' => true,
                  'presetDropdown'=>true,
                  'pluginOptions'=>[
                      'locale'=>['format'=>'Y-m-d'],
                  ]
              ]),
            ],
            [
              'header' => Yii::t('app', "Actions"),
              'class' => 'yii\grid\ActionColumn',
              'template' => '{update} {view}{delete}',
              'contentOptions' => ['style' => 'width:50px;  min-width:50px;'],
            ],
        ]
      ])?>
    <?= Html::button('<span class="glyphicon glyphicon-trash" aria-hidden="true"></span>', ['class' => 'btn btn-danger', 'id'=>'btn-confirm', 'disabled'=>'disabled']) ?>
    <?= Html::a(Yii::t('app', 'Create Notifications Details'), ['create'], ['class' => 'btn btn-success']) ?>
    <?= Html::endForm();?>
</div>

<!-- Delete row selected -->
<?php echo
  Dialog::widget([
     'libName' => 'deleteBulk',
     'options' => [
       'title' => 'Delete',
       'closable' => true,
       'type' => Dialog::TYPE_DANGER,
       'btnOKClass' => 'btn-danger',
     ], // custom options
  ]);
  $this->registerJs(
    '$(".btn-delete").on("click", function() {
        var obj = $(this).closest("tr").data("key");
        deleteBulk.confirm("Confirm delete?", function (result) {
          if (result) {
            $.ajax({
                url:"delete",
                data:{"id":obj.id},
                success:function(res){
                  console.log(res);
                }
            });
          }
        });
    });'
   );
?>

<!-- Delete in bulk -->
<?php echo
  Dialog::widget([
     'libName' => 'krajeeDialog',
     'options' => [
       'title' => 'Delete',
       'closable' => true,
       'type' => Dialog::TYPE_DANGER,
       'btnOKClass' => 'btn-danger',
     ], // custom options
  ]);
  $this->registerJs('
    $("#btn-confirm").on("click", function() {
        krajeeDialog.confirm("Confirm delete of the selected items?", function (result) {
            if (result) {
                var form = $("form#bulk-del");
                $.ajax({
                      url    : "bulk",
                      type   : "POST",
                      data   : form.serialize(),
                      success: function (response)
                      {
                         console.log(response);
                      },
                      error  : function (e)
                      {
                          console.log(e);
                      }
                  });
            }
        });
    });
  ');
?>

<!-- Check if ENABLE or DISABLED buttons -->
<?php echo
  $this->registerJs('
    $(":checkbox").change(function() {
        if($(\'[name="selection[]"]:checked\').length > 0){
          $("#btn-confirm").prop("disabled", false);
        }else{
          $("#btn-confirm").prop("disabled", true);
        }
    });
  ');
?>
