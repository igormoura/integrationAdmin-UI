<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="user-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="col-md-6">
      <?= $form->field($model, 'username')->textInput(['maxlength' => true]) ?>
    </div>

    <div class="col-md-6">
      <?= $form->field($model, 'status')->dropdownList([
        0  => 'Inactive',
        10 => 'Active'
      ],
      ['prompt'=>'Select Status']) ?>
    </div>

    <div class="col-md-12">
      <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>
    </div>

    <div class="col-md-6">
      <?= $form->field($model, 'password_hash')->input('password')->label($model->isNewRecord ? 'Password' : 'New Password') ?>
    </div>

    <div class="col-md-6">
      <?= $form->field($model, 'password_confirmation')->input('password') ?>
    </div>

    <div class="form-group col-md-12">
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
