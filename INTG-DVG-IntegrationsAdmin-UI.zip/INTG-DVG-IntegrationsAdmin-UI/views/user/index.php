<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Breadcrumbs;

/* @var $this yii\web\View */
/* @var $searchModel app\models\searchs\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

 $this->title = Yii::t('app', 'Users');
 $this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Admin'), 'url' => ['/admin']];
 $this->params['breadcrumbs'][] = $this->title;

?>
<div class="user-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a(Yii::t('app', 'Create User'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'username',
            'email:email',
            'status',
            [
                'attribute' => 'created_at',
                'format' => ['date', 'php:m/d/Y']
            ],
            [
              'class' => 'yii\grid\ActionColumn',
              'header' => 'Actions',
              'headerOptions' => ['style' => 'color:#337ab7'],
              'template' => '{view}{update}{assignment}',
              'buttons' => [
                'view' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', $url, [
                                'title' => Yii::t('app', 'View'),
                    ]);
                },
                'update' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-pencil"></span>', $url, [
                                'title' => Yii::t('app', 'Update'),
                    ]);
                },
                'assignment' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-cog"></span>', $url, [
                                'title' => Yii::t('app', 'Assignment'),
                    ]);
                }
              ],
              'urlCreator' => function ($action, $model, $key, $index) {
                if ($action === 'view') {
                    $url ='/user/'.$model->id;
                    return $url;
                }
                if ($action === 'update') {
                    $url ='/user/update/'.$model->id;
                    return $url;
                }
                if ($action === 'assignment') {
                    $url ='/admin/assignment/view?id='.$model->id;
                    return $url;
                }
              }
          ],
        ],
    ]); ?>
</div>
