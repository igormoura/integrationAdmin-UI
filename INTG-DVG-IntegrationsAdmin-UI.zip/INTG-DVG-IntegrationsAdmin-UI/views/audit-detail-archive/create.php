<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\AuditDetailArchive */

$this->title = Yii::t('app', 'Create Audit Detail Archive');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Audit Detail Archives'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="audit-detail-archive-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
