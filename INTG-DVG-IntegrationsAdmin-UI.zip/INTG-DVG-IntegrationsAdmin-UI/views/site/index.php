<?php

/* @var $this yii\web\View */

$this->title = 'Integrations Admin';
?>
<div class="site-index">
    <div class="jumbotron">
        <h1>Welcome to integrations admin!</h1>
    </div>
    </div>
</div>
