<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $searchModel mdm\admin\models\searchs\Assignment */
/* @var $usernameField string */
/* @var $extraColumns string[] */

$this->title = Yii::t('rbac-admin', 'Users');
$this->params['breadcrumbs'][] = $this->title;

$columns = [
    ['class' => 'yii\grid\SerialColumn'],
    $usernameField,
];
if (!empty($extraColumns)) {
    $columns = array_merge($columns, $extraColumns);
}

$columns[] = [
    'class' => 'yii\grid\ActionColumn',
    'header' => 'Actions',
    'headerOptions' => ['style' => 'color:#337ab7'],
    'template' => '{view}{update}{assignment}',
    'contentOptions' => ['style' => 'width:30px;  min-width:30px;'],
    'buttons' => [
      'view' => function ($url, $model) {
          return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', '/user/view/'.$model->ID, [
                      'title' => Yii::t('app', 'View'),
          ]);
      },
      'update' => function ($url, $model) {
          return Html::a('<span class="glyphicon glyphicon-pencil"></span>', '/user/update/'.$model->ID, [
                      'title' => Yii::t('app', 'Update'),
          ]);
      },
      'assignment' => function ($url, $model) {
          return Html::a('<span class="glyphicon glyphicon-cog"></span>', '/admin/assignment/view?id='.$model->ID, [
                      'title' => Yii::t('app', 'View'),
          ]);
      }
    ],
];

?>
<div class="assignment-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => $columns,
    ]);
    ?>
    <?php Pjax::end(); ?>
</div>

 <p>
    <?= Html::a(Yii::t('app', 'Create User'), ['/user/create'], ['class' => 'btn btn-success']) ?>
</p>
