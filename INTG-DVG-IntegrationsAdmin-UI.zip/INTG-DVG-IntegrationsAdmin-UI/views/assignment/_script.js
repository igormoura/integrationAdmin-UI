$('i.glyphicon-refresh-animate').hide();

function updateItems(r) {
    _opts.items.available = r.available;
    _opts.items.assigned = r.assigned;
    search('available');
    search('assigned');
}

$('#save-assignment').click(function () {
  var assigneds = $( "select[data-target='assigned'] option" );
  var availables = $( "select[data-target='available'] option" );

  var arrayAssigneds = [];
  assigneds.each(function(){
    arrayAssigneds.push($(this).val())
  });

  var arrayAvailables = [];
  availables.each(function(){
    arrayAvailables.push($(this).val())
  });

  if (assigneds && assigneds.length) {
    $.post($('.btn-assign').attr('href'), {assigneds: arrayAssigneds, availables: arrayAvailables}, function (r) {
      $.notify({
        message: "Saved with successfully.",
      },{
        type: "success",
        animate: {
          enter: "animated fadeInDown",
          exit: "animated fadeOutUp"
        }
      });
    }).always(function () {
    });
  }
});

$('.btn-assign').click(function () {
    var target = $(this).data('target');
    var otherTarget = (target == "available" ? "assigned" : "available");
    var options = $( "select[data-target="+target+"] option:selected" );
    options.each(function() {
      var group = $(this).parent();
      var label = group.attr('label');
      if(!$("select[data-target="+otherTarget+"] optgroup[label="+label+"]").length){
        var optgroup = document.createElement("optgroup");
        $(optgroup).attr('label', label);
        $("select[data-target="+otherTarget+"]").prepend(optgroup);
      }
      var html = $(this)[0].outerHTML;
      $("select[data-target="+target+"] option[value='"+$(this).val()+"']").remove();
      $("select[data-target="+otherTarget+"] optgroup[label="+label+"]").append(html);
    });
    var assigneds = $( "select[data-target="+otherTarget+"] optgroup option" );
    assigneds.sort(compare);
    $("select[data-target="+otherTarget+"] optgroup").innerHTML = '';
    assigneds.each(function(){
      var group = $(this).parent();
      var label = group.attr('label');
      $("select[data-target="+otherTarget+"] optgroup[label="+label+"]").append($(this));
    });
    return false;
});

$('.search[data-target]').keyup(function () {
    search($(this).data('target'));
});

function search(target) {
    var $list = $('select.list[data-target="' + target + '"]');
    $list.html('');
    var q = $('.search[data-target="' + target + '"]').val();

    var groups = {
        role: [$('<optgroup label="Roles">'), false],
        permission: [$('<optgroup label="Permission">'), false],
    };
    $.each(_opts.items[target], function (name, group) {
        if (name.indexOf(q) >= 0) {
            $('<option>').text(name).val(name).appendTo(groups[group][0]);
            groups[group][1] = true;
        }
    });
    $.each(groups, function () {
        if (this[1]) {
            $list.append(this[0]);
        }
    });
}

function compare(a,b) {
  if (a.innerHTML < b.innerHTML)
    return -1;
  if (a.innerHTML > b.innerHTML)
    return 1;
  return 0;
}

// initial
search('available');
search('assigned');
