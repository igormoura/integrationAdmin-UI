<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;

/* @var $this yii\web\View */
/* @var $model app\models\ConfigService */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="config-service-form">
    <?php $form = ActiveForm::begin(); ?>

    <!-- $model->isNewRecord -->

    <div class="row">
      <div class="col-md-6">
        <?= $form->field($model, 'INTG_NAME')->textInput(['maxlength' => true, 'readonly' => !$model->isNewRecord ]) ?>
      </div>
      <div class="col-md-6">
        <?= $form->field($model, 'INSTITUTION')->dropDownList($institutions, ['class' => !$model->isNewRecord ? 'form-control enabled-select' : 'form-control']); ?>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <?= $form->field($model, 'KEY')->textInput(['maxlength' => true, 'readonly' => !$model->isNewRecord]) ?>
      </div>
      <div class="col-md-6">
        <?= $form->field($model, 'VALUE')->textInput(['maxlength' => true]) ?>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <?= $form->field($model, 'TYPE')->textInput(['maxlength' => true, 'readonly' => !$model->isNewRecord]) ?>
      </div>
      <div class="col-md-6">
        <?= $form->field($model, 'STATUS')->dropDownList(['A'=>'Active','I'=>'Inactive']); ?>
      </div>
    </div>

    <div class="form-group">
        <?= Html::a(Yii::t('app', 'Cancel'), ['index'], ['class' => 'btn btn-default']) ?>
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
