<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\daterange\DateRangePicker;
use kartik\select2\Select2;
use kartik\dialog\Dialog;

/* @var $this yii\web\View */
/* @var $searchModel app\models\searchs\ConfigService */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = Yii::t('app', 'Config Services');
$this->params['breadcrumbs'][] = $this->title;

?>

<div class="config-service-index">
    <h1><?= Html::encode($this->title) ?></h1>
    <?= Html::beginForm(['bulk'],'post', ['id'=>'bulk-del']);?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
              'class' => 'yii\grid\CheckboxColumn', 'checkboxOptions' => function($model) {
                    return ['value' => $model->KEY];
              },
            ],
            [
              'label' => Yii::t('app', "Institutions"),
              'attribute' => 'INSTITUTION',
              'filter' => Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'INSTITUTION',
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'data' =>  $institutions,
                    'options' => ['multiple' => true, 'placeholder' => 'Select institution ...'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ]),
            ],
            'INTG_NAME',
            'TYPE',
            'KEY',
            'VALUE',
            'CREATED_BY',
            'LAST_MODIFIED_BY',
            [
              'label' => Yii::t('app', "Status"),
              'attribute' => 'STATUS',
              'content'=> function($data){
                return $data->STATUS == 'A' ? '<span class="label label-success">Active</span>' : '<span class="label label-danger">Inactive</span>';
              },
              'filter' => Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'STATUS',
                    'value' => 'A',
                    'theme' => Select2::THEME_BOOTSTRAP,
                    'data' =>  ['A'=> 'Active', 'I'=>'Inactive'],
                    'value' => 'A',
                    'options' => ['multiple' => false, 'placeholder' => 'Status'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ]),
              'contentOptions' => ['style' => 'width:100px;  min-width:100px;'],
            ],
            [
              'label' => Yii::t('app', "Created at"),
              'attribute' => 'CREATED_DATE',
              'format' => 'date',
              'filter' => DateRangePicker::widget([
                  'model' => $searchModel,
                  'attribute'=>'CREATED_DATE',
                  'convertFormat' => true,
                  'presetDropdown'=>true,
                  'pluginOptions'=>[
                      'locale'=>['format'=>'Y-m-d'],
                  ]
              ]),
            ],
            [
              'label' => Yii::t('app', "Updated at"),
              'attribute' => 'LAST_MODIFICATION_DATE',
              'format' => 'date',
              'filter' => DateRangePicker::widget([
                  'model' => $searchModel,
                  'attribute'=>'LAST_MODIFICATION_DATE',
                  'convertFormat' => true,
                  'presetDropdown'=>true,
                  'pluginOptions'=>[
                      'locale'=>['format'=>'Y-m-d'],
                  ]
              ]),
            ],
            [
              'class' => 'yii\grid\ActionColumn',
              'header' => 'Actions',
              'headerOptions' => ['style' => 'color:#337ab7'],
              'template' => '{view}{update}{delete}',
              'contentOptions' => ['style' => 'width:50px;  min-width:50px;'],
              'buttons' => [
                'view' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-eye-open"></span>', $url, [
                                'title' => Yii::t('app', 'View'),
                    ]);
                },
                'update' => function ($url, $model) {
                    return Html::a('<span class="glyphicon glyphicon-pencil"></span>', $url, [
                                'title' => Yii::t('app', 'Update'),
                    ]);
                },
                'delete' => function ($url, $model) {
                    return Html::a('<span class="glyphicon '.($model->STATUS=="I" ? "glyphicon-ok" : "glyphicon-ban-circle"). '"></span>', '#', [
                                'class' => 'btn-delete',
                                'title' => Yii::t('app', 'Change status')
                    ]);
                }
              ],
              'urlCreator' => function ($action, $model, $key, $index) {
                if ($action === 'view') {
                    $url ='/config-service/view?INTG_NAME='.$model->INTG_NAME.'&KEY='.$model->KEY;
                    return $url;
                }
                if ($action === 'update') {
                    $url ='/config-service/update?INTG_NAME='.$model->INTG_NAME.'&KEY='.$model->KEY;
                    return $url;
                }
              }
          ],
        ],
    ]); ?>
    <?= Html::button('<span class="glyphicon glyphicon-ok" aria-hidden="true"></span>', ['class' => 'btn btn-success btn-confirm', 'id'=>'btn-confirm-ok', 'disabled'=>'disabled']) ?>
    <?= Html::button('<span class="glyphicon glyphicon-ban-circle" aria-hidden="true"></span>', ['class' => 'btn btn-danger btn-confirm', 'id'=>'btn-confirm-ban', 'disabled'=>'disabled']) ?>
    <?= Html::a(Yii::t('app', 'Create Config Service'), ['create'], ['class' => 'btn btn-primary']) ?>
    <?= Html::endForm();?>
</div>

<!-- Change STATUS row selected -->
<?php echo
  Dialog::widget([
     'libName' => 'changeStatus',
     'options' => [
       'title' => 'Change Status',
       'closable' => true,
     ], // custom options
  ]);
  $this->registerJs(
    '$(".btn-delete").on("click", function() {
        var obj = $(this).closest("tr").data("key");
        changeStatus.confirm("Confirm change status?", function (result) {
          if (result) {
            $.ajax({
                url:"delete",
                data:{"INTG_NAME":obj.INTG_NAME, "KEY": obj.KEY},
                success:function(res){
                  console.log(res);
                }
            });
          }
        });
    });'
   );
?>

<!-- Change STATUS to INACTIVE in bulk -->
<?php echo
  Dialog::widget([
     'libName' => 'deleteBulk',
     'options' => [
       'title' => 'Change Status',
       'closable' => true,
       'type' => Dialog::TYPE_DANGER,
       'btnOKClass' => 'btn-danger',
     ], // custom options
  ]);
  $this->registerJs('
    $("#btn-confirm-ban").on("click", function() {
        deleteBulk.confirm("Confirm change status to inactive of the selected items?", function (result) {
            if (result) {
                var form = $("form#bulk-del");
                $.ajax({
                      url    : "disabledbulk",
                      type   : "POST",
                      data   : form.serialize(),
                      success: function (response)
                      {
                         console.log(response);
                      },
                      error  : function (e)
                      {
                          console.log(e);
                      }
                  });
            }
        });
    });
  ');
?>

<!-- Change STATUS to INACTIVE in bulk -->
<?php echo
  Dialog::widget([
     'libName' => 'activeBulk',
     'options' => [
       'title' => 'Change Status',
       'closable' => true,
       'type' => Dialog::TYPE_SUCCESS,
       'btnOKClass' => 'btn-success',
     ], // custom options
  ]);
  $this->registerJs('
    $("#btn-confirm-ok").on("click", function() {
        activeBulk.confirm("Confirm change status to active of the selected items?", function (result) {
            if (result) {
                var form = $("form#bulk-del");
                $.ajax({
                      url    : "activebulk",
                      type   : "POST",
                      data   : form.serialize(),
                      success: function (response)
                      {
                         console.log(response);
                      },
                      error  : function (e)
                      {
                          console.log(e);
                      }
                  });
            }
        });
    });
  ');
?>

<!-- Check if ENABLE or DISABLED buttons -->
<?php echo
  $this->registerJs('
    $(":checkbox").change(function() {
        if($(\'[name="selection[]"]:checked\').length > 0){
          $(".btn-confirm").prop("disabled", false);
        }else{
          $(".btn-confirm").prop("disabled", true);
        }
    });
  ');
?>
