<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\searchs\ConfigService */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="config-service-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'INTG_NAME') ?>

    <?= $form->field($model, 'KEY') ?>

    <?= $form->field($model, 'VALUE') ?>

    <?= $form->field($model, 'TYPE') ?>

    <?= $form->field($model, 'STATUS') ?>

    <?php // echo $form->field($model, 'CREATED_BY') ?>

    <?php // echo $form->field($model, 'CREATED_DATE') ?>

    <?php // echo $form->field($model, 'LAST_MODIFIED_BY') ?>

    <?php // echo $form->field($model, 'LAST_MODIFICATION_DATE') ?>

    <?php // echo $form->field($model, 'INSTITUTION') ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Search'), ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton(Yii::t('app', 'Reset'), ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
