<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\ConfigService */

$this->title = $model->INTG_NAME;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Config Services'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="config-service-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a(Yii::t('app', 'Update'), ['update', 'INTG_NAME' => $model->INTG_NAME, 'KEY' => $model->KEY, 'INSTITUTION' => $model->INSTITUTION], ['class' => 'btn btn-primary']) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'INTG_NAME',
            'KEY',
            'VALUE',
            'TYPE',
            'STATUS',
            'CREATED_BY',
            'CREATED_DATE',
            'LAST_MODIFIED_BY',
            'LAST_MODIFICATION_DATE',
            'INSTITUTION',
        ],
    ]) ?>

</div>
