<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "audit".
 *
 * @property int $ID
 * @property string $BATCH_ID
 * @property string $DSI
 * @property string $SOURCE
 * @property string $TARGET
 * @property string $INSTITUTION
 * @property string $INTEGRATION
 * @property string $SERVICE
 * @property string $ENDPOINT_URL
 * @property string $STATUS
 * @property string $ERROR_CODE
 * @property string $REASON
 * @property int $RETRY_COUNT
 * @property string $MSG_ID
 * @property string $RETRY_COUNT_EMAIL
 * @property string $RETRY_TS
 * @property string $CREATED_TS
 */
class AuditArchive extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'audit';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db_archives');
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['RETRY_COUNT'], 'integer'],
            [['RETRY_TS', 'CREATED_TS'], 'safe'],
            [['BATCH_ID', 'DSI'], 'string', 'max' => 10],
            [['SOURCE', 'TARGET', 'INTEGRATION', 'SERVICE', 'ENDPOINT_URL', 'REASON'], 'string', 'max' => 255],
            [['INSTITUTION'], 'string', 'max' => 5],
            [['STATUS', 'ERROR_CODE', 'RETRY_COUNT_EMAIL'], 'string', 'max' => 1],
            [['MSG_ID'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'BATCH_ID' => Yii::t('app', 'Batch  ID'),
            'DSI' => Yii::t('app', 'Dsi'),
            'SOURCE' => Yii::t('app', 'Source'),
            'TARGET' => Yii::t('app', 'Target'),
            'INSTITUTION' => Yii::t('app', 'Institution'),
            'INTEGRATION' => Yii::t('app', 'Integration'),
            'SERVICE' => Yii::t('app', 'Service'),
            'ENDPOINT_URL' => Yii::t('app', 'Endpoint  Url'),
            'STATUS' => Yii::t('app', 'Status'),
            'ERROR_CODE' => Yii::t('app', 'Error  Code'),
            'REASON' => Yii::t('app', 'Reason'),
            'RETRY_COUNT' => Yii::t('app', 'Retry  Count'),
            'MSG_ID' => Yii::t('app', 'Msg  ID'),
            'RETRY_COUNT_EMAIL' => Yii::t('app', 'Retry  Count  Email'),
            'RETRY_TS' => Yii::t('app', 'Retry  Ts'),
            'CREATED_TS' => Yii::t('app', 'Created  Ts'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAuditDetail()
    {
        return $this->hasOne(AuditDetailArchive::className(), ['ID' => 'ID']);
    }

    public function getPayload(){
      return $this->auditDetail->PAYLOAD;
    }
}
