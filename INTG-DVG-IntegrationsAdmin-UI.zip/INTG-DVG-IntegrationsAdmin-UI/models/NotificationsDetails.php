<?php

namespace app\models;

use Yii;
use yii\behaviors\TimestampBehavior;

/**
 * This is the model class for table "notifications_details".
 *
 * @property int $id
 * @property string $process_code
 * @property string $event_code
 * @property string $event_desc
 * @property string $mail_list
 * @property string $from_list
 * @property string $institution
 * @property int $created_by
 * @property int $updated_by
 * @property string $created_at
 * @property string $updated_at
 *
 * @property User $createdBy
 * @property User $updatedBy
 */
class NotificationsDetails extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'notifications_details';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['created_by', 'updated_by', 'process_code', 'event_code', 'institution'], 'required'],
            [['created_at', 'updated_at'], 'safe'],
            [['process_code', 'event_code', 'event_desc', 'mail_list', 'from_list', 'institution'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'process_code' => Yii::t('app', 'Process Code'),
            'event_code' => Yii::t('app', 'Event Code'),
            'event_desc' => Yii::t('app', 'Event Desc'),
            'mail_list' => Yii::t('app', 'To Email List'),
            'from_list' => Yii::t('app', 'From Mail'),
            'institution' => Yii::t('app', 'Institution'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
            'created_at' => Yii::t('app', 'Created At'),
            'updated_at' => Yii::t('app', 'Updated At'),
        ];
    }
}
