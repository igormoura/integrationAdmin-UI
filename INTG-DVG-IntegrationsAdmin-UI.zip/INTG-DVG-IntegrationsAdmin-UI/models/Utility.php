<?php

namespace app\models;

use Yii;
use yii\db\Query;
use  yii\web\Session;

class Utility {

    public static function getInstitutions(){

      $user_id = Yii::$app->user->getId();

      $groups[] = array();
      $institutions[] = array();

      $query = new Query;

      $query->select('item_name')
            ->from('auth_assignment')
            ->where(['user_id' => $user_id])
            ->all();
      $res = $query->all();

      foreach ($res as $group) {
        $groups[]=$group['item_name'];
      }

      unset($institutions[0]);
      unset($groups[0]);

      if(in_array("Admin", $groups)){
        $query = new Query;
        $query->select('name')
              ->from('auth_item')
              ->where(['type' => 1])
              ->all();
        $res = $query->all();

        foreach ($res as $item) {
          $institutions[$item['name']]=$item['name'];
        }
        unset($institutions['Admin']);
      }else {
        if(!empty($groups)){
          foreach ($groups as $item) {
            $institutions[$item]=$item;
          }
        }
      }
      return $institutions;
    }
}
?>
