<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "integration".
 *
 * @property string $INSTITUTION
 * @property string $INTEGRATION
 * @property string $FIRST_OR_LAST
 * @property string $REPROCESS
 * @property string $CREATED_BY
 * @property string $CREATED_TS
 */
class AuditControl extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'integration';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db');
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['INSTITUTION', 'INTEGRATION', 'REPROCESS'], 'required'],
            [['CREATED_TS'], 'safe'],
            [['INTEGRATION', 'CREATED_BY'], 'string', 'max' => 255],
            [['FIRST_OR_LAST', 'REPROCESS'], 'string', 'max' => 1],
            [['INSTITUTION', 'INTEGRATION'], 'unique', 'targetAttribute' => ['INSTITUTION', 'INTEGRATION']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'INSTITUTION' => Yii::t('app', 'Institution'),
            'INTEGRATION' => Yii::t('app', 'Integration'),
            'FIRST_OR_LAST' => Yii::t('app', 'First  Or  Last'),
            'REPROCESS' => Yii::t('app', 'Reprocess'),
            'CREATED_BY' => Yii::t('app', 'Created  By'),
            'CREATED_TS' => Yii::t('app', 'Created  Ts')
        ];
    }
}
