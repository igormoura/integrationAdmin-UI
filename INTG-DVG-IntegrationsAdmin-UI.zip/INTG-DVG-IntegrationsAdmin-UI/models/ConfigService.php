<?php

namespace app\models;
use yii\behaviors\TimestampBehavior;
use yii\db\Expression;

use Yii;

/**
 * This is the model class for table "config".
 *
 * @property string $INTG_NAME
 * @property string $KEY
 * @property string $VALUE
 * @property string $TYPE
 * @property string $STATUS
 * @property string $CREATED_BY
 * @property string $CREATED_DATE
 * @property string $LAST_MODIFIED_BY
 * @property string $LAST_MODIFICATION_DATE
 * @property string $INSTITUTION
 */
class ConfigService extends \yii\db\ActiveRecord
{

    public static function primaryKey(){
       return array('INTG_NAME', 'KEY', 'INSTITUTION');
    }

    public static function getDb() {
        return Yii::$app->db;
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'config';
    }

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            [
                'class' => TimestampBehavior::className(),
                // if fields have different names they can be defined in following lines
                'createdAtAttribute' => 'CREATED_DATE',
                'updatedAtAttribute' => 'LAST_MODIFICATION_DATE',
                'value' => new Expression('NOW()'),
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['INTG_NAME', 'KEY', 'CREATED_BY', 'LAST_MODIFIED_BY', 'INSTITUTION', 'VALUE'], 'required'],
            [['CREATED_DATE', 'LAST_MODIFICATION_DATE'], 'safe'],
            [['INTG_NAME', 'KEY', 'VALUE', 'TYPE', 'CREATED_BY', 'LAST_MODIFIED_BY', 'INSTITUTION'], 'string', 'max' => 255],
            [['STATUS'], 'string', 'max' => 1],
            [['INTG_NAME', 'KEY', 'INSTITUTION'], 'unique', 'targetAttribute' => ['INTG_NAME', 'KEY', 'INSTITUTION']]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'INTG_NAME' => Yii::t('app', 'Intg  Name'),
            'KEY' => Yii::t('app', 'Key'),
            'VALUE' => Yii::t('app', 'Value'),
            'TYPE' => Yii::t('app', 'Type'),
            'STATUS' => Yii::t('app', 'Status'),
            'CREATED_BY' => Yii::t('app', 'Created  By'),
            'CREATED_DATE' => Yii::t('app', 'Created  Date'),
            'LAST_MODIFIED_BY' => Yii::t('app', 'Last  Modified  By'),
            'LAST_MODIFICATION_DATE' => Yii::t('app', 'Last  Modification  Date'),
            'INSTITUTION' => Yii::t('app', 'Institution'),
        ];
    }
}
