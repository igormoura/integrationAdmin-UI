<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "audit_detail".
 *
 * @property int $ID
 * @property resource $PAYLOAD
 */
class AuditDetail extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'audit_detail';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ID'], 'required'],
            [['ID'], 'integer'],
            [['PAYLOAD'], 'string'],
            [['ID'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ID' => Yii::t('app', 'ID'),
            'PAYLOAD' => Yii::t('app', 'Payload'),
        ];
    }
}
