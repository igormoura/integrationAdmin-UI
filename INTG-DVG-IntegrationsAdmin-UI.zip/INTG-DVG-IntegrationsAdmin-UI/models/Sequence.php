<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "sequence".
 *
 * @property string $NAME
 * @property int $CURRENT_VALUE
 * @property int $INCREMENT
 */
class Sequence extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sequence';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['NAME', 'CURRENT_VALUE'], 'required'],
            [['CURRENT_VALUE', 'INCREMENT'], 'integer'],
            [['NAME'], 'string', 'max' => 50],
            [['NAME'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'NAME' => Yii::t('app', 'Name'),
            'CURRENT_VALUE' => Yii::t('app', 'Current  Value'),
            'INCREMENT' => Yii::t('app', 'Increment'),
        ];
    }
}
