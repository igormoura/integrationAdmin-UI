<?php

namespace app\models\searchs;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\AuditArchive as AuditArchiveModel;

/**
 * AuditArchive represents the model behind the search form of `app\models\AuditArchive`.
 */
class AuditArchive extends AuditArchiveModel
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ID', 'RETRY_COUNT'], 'integer'],
            [['BATCH_ID', 'DSI', 'SOURCE', 'TARGET', 'INSTITUTION', 'INTEGRATION', 'SERVICE', 'ENDPOINT_URL', 'STATUS', 'ERROR_CODE', 'REASON', 'MSG_ID', 'RETRY_COUNT_EMAIL', 'RETRY_TS', 'CREATED_TS'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = AuditArchiveModel::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 100,
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        if(!empty($this->INSTITUTION)){
            if(is_array($this->INSTITUTION)){
                foreach ($this->INSTITUTION as $value){
                    $query->orFilterWhere(['=', 'INSTITUTION', $value]);
                }
            }else{
                $query->andFilterWhere(['=', 'INSTITUTION', $this->INSTITUTION]);
            }
        }

        $query->andFilterWhere([
            'ID' => $this->ID,
            'RETRY_COUNT' => $this->RETRY_COUNT,
            'RETRY_TS' => $this->RETRY_TS,
        ]);

        $query->andFilterWhere(['like', 'BATCH_ID', $this->BATCH_ID])
            ->andFilterWhere(['like', 'DSI', $this->DSI])
            ->andFilterWhere(['like', 'SOURCE', $this->SOURCE])
            ->andFilterWhere(['like', 'TARGET', $this->TARGET])
            ->andFilterWhere(['like', 'INSTITUTION', $this->INSTITUTION])
            ->andFilterWhere(['like', 'INTEGRATION', $this->INTEGRATION])
            ->andFilterWhere(['like', 'SERVICE', $this->SERVICE])
            ->andFilterWhere(['like', 'ENDPOINT_URL', $this->ENDPOINT_URL])
            ->andFilterWhere(['like', 'STATUS', $this->STATUS])
            ->andFilterWhere(['like', 'ERROR_CODE', $this->ERROR_CODE])
            ->andFilterWhere(['like', 'REASON', $this->REASON])
            ->andFilterWhere(['like', 'MSG_ID', $this->MSG_ID])
            ->andFilterWhere(['like', 'RETRY_COUNT_EMAIL', $this->RETRY_COUNT_EMAIL]);

        if(!empty($this->CREATED_TS)){
            $START_DATE = substr($this->CREATED_TS, 0, 10);
            $END_DATE = substr($this->CREATED_TS, 13);
            $query->andFilterWhere(['between', $this->tableName().'.CREATED_TS', $START_DATE.' 00:00:00', $END_DATE.' 23:59:59']);
        }

        return $dataProvider;
    }
}
