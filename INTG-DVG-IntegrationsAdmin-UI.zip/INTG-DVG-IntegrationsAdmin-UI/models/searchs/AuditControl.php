<?php

namespace app\models\searchs;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\AuditControl as AuditControlModel;
use app\models\Utility;

/**
 * Integration represents the model behind the search form of `app\models\Integration`.
 */
class AuditControl extends AuditControlModel
{
    public $createdByName;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['INSTITUTION', 'INTEGRATION', 'FIRST_OR_LAST', 'REPROCESS', 'CREATED_BY', 'CREATED_TS'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $institutions = Utility::getInstitutions();
        $query = AuditControlModel::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 100,
            ],
        ]);

        $this->load($params);

        $dataProvider->setSort([
           'attributes' => [
               'INSTITUTION',
               'REPROCESS',
               'INTEGRATION',
               'CREATED_TS',
               'CREATED_BY',
               'createdByName' => [
                   'asc' => ['user.username' => SORT_ASC],
                   'desc' => ['user.username' => SORT_DESC]
               ]
           ]
       ]);

       if (!$this->validate()) {
           // uncomment the following line if you do not want to return any records when validation fails
           // $query->where('0=1');
           return $dataProvider;
       }

        // grid filtering conditions
        if(!empty($this->INSTITUTION)){
            if(is_array($this->INSTITUTION)){
                foreach ($this->INSTITUTION as $value){
                    $query->orFilterWhere(['=', 'INSTITUTION', $value]);
                }
            }else{
                $query->andFilterWhere(['=', 'INSTITUTION', $this->INSTITUTION]);
            }
        }

        $query->andFilterWhere(['like', 'INSTITUTION', $this->INSTITUTION])
            ->andFilterWhere(['like', 'INTEGRATION', $this->INTEGRATION])
            ->andFilterWhere(['like', 'FIRST_OR_LAST', $this->FIRST_OR_LAST])
            ->andFilterWhere(['like', 'REPROCESS', $this->REPROCESS])
            ->andFilterWhere(['like', 'CREATED_BY', $this->CREATED_BY]);

        if(!empty($this->CREATED_TS)){
            $START_DATE = substr($this->CREATED_TS, 0, 10);
            $END_DATE = substr($this->CREATED_TS, 13);
            $query->andFilterWhere(['between', $this->tableName().'.CREATED_TS', $START_DATE.' 00:00:00', $END_DATE.' 23:59:59']);
        }

        return $dataProvider;
    }
}
