<?php

namespace app\models\searchs;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ConfigService as ConfigServiceModel;
use app\models\Utility;

/**
 * ConfigService represents the model behind the search form of `app\models\ConfigService`.
 */
class ConfigService extends ConfigServiceModel
{
    public $createdByName;
    public $updatedByName;

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['INTG_NAME', 'KEY', 'VALUE', 'TYPE', 'STATUS', 'CREATED_BY', 'CREATED_DATE', 'LAST_MODIFIED_BY', 'LAST_MODIFICATION_DATE', 'INSTITUTION', 'createdByName', 'updatedByName'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $institutions = Utility::getInstitutions();
        $query = ConfigServiceModel::find();

        // add conditions that should always apply here
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 100,
            ],
        ]);

        $this->load($params);

        // validate if exist parameter institution in search, if not, get institutions via permissions
        if((empty($this->INSTITUTION)) && (!empty($institutions))){
            foreach ($institutions as $item) {
                $query->orWhere(['OR', 'INSTITUTION="'.$item.'"']);
            }
        } else if(empty($institutions)){
            $query->andFilterWhere(['=', 'INSTITUTION', 'null']);
        }

        /**
         * Setup your sorting attributes
         * Note: This is setup before the $this->load($params)
         * statement below
         */
         $dataProvider->setSort([
            'attributes' => [
                'INSTITUTION',
                'INTG_NAME',
                'TYPE',
                'KEY',
                'VALUE',
                'STATUS',
                'CREATED_DATE',
                'LAST_MODIFICATION_DATE',
                'CREATED_BY',
                'LAST_MODIFIED_BY',
            ]
        ]);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        if(!empty($this->INSTITUTION)){
            if(is_array($this->INSTITUTION)){
                foreach ($this->INSTITUTION as $value){
                    $query->orFilterWhere(['=', 'INSTITUTION', $value]);
                }
            }else{
                $query->andFilterWhere(['=', 'INSTITUTION', $this->INSTITUTION]);
            }
        }

        $query->andFilterWhere(['like', 'INTG_NAME', $this->INTG_NAME])
            ->andFilterWhere(['like', 'KEY', $this->KEY])
            ->andFilterWhere(['like', 'VALUE', $this->VALUE])
            ->andFilterWhere(['like', 'TYPE', $this->TYPE])
            ->andFilterWhere(['like', 'STATUS', $this->STATUS])
            ->andFilterWhere(['like', 'CREATED_BY', $this->CREATED_BY])
            ->andFilterWhere(['like', 'LAST_MODIFIED_BY', $this->LAST_MODIFIED_BY]);

        if(!empty($this->CREATED_DATE)){
            $START_DATE = substr($this->CREATED_DATE, 0, 10);
            $END_DATE = substr($this->CREATED_DATE, 13);
            $query->andFilterWhere(['between', $this->tableName().'.CREATED_DATE', $START_DATE.' 00:00:00', $END_DATE.' 23:59:59']);
        }

        if(!empty($this->LAST_MODIFICATION_DATE)){
            $START_DATE = substr($this->LAST_MODIFICATION_DATE, 0, 10);
            $END_DATE = substr($this->LAST_MODIFICATION_DATE, 13);
            $query->andFilterWhere(['between', $this->tableName().'.LAST_MODIFICATION_DATE', $START_DATE.' 00:00:00', $END_DATE.' 23:59:59']);
        }

        return $dataProvider;
    }
}
