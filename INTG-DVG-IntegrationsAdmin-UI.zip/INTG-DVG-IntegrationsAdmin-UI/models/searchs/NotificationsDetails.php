<?php
namespace app\models\searchs;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\NotificationsDetails as NotificationsDetailsModel;
use app\models\Utility;

/**
 * NotificationsDetails represents the model behind the search form of `app\models\NotificationsDetails`.
 */

class NotificationsDetails extends NotificationsDetailsModel
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['process_code', 'event_code', 'event_desc', 'mail_list', 'from_list', 'institution', 'created_at', 'updated_at', 'created_by', 'updated_by'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        try {
          $institutions = Utility::getInstitutions();
          $query = NotificationsDetailsModel::find();

          // add conditions that should always apply here
          $dataProvider = new ActiveDataProvider([
              'query' => $query,
              'pagination' => [
                  'pageSize' => 100,
              ],
          ]);

          // get parameters and load dado to filter
          $this->load($params);

          // validate if exist parameter institution in search, if not, get institutions via permissions
          if((empty($this->institution)) && (!empty($institutions))){
              foreach ($institutions as $item) {
                  $query->orWhere(['OR', 'institution="'.$item.'"']);
              }
          }

          /**
           * Setup your sorting attributes
           * Note: This is setup before the $this->load($params)
           * statement below
           */
           $dataProvider->setSort([
              'attributes' => [
                  'institution',
                  'process_code',
                  'event_code',
                  'from_list',
                  'mail_list',
                  'updated_at',
                  'created_at',
                  'created_by',
                  'updated_by',
              ]
          ]);

          if (!$this->validate()) {
              // uncomment the following line if you do not want to return any records when validation fails
              // $query->where('0=1');
              return $dataProvider;
          }

          // grid filtering conditions
          if(!empty($this->institution)){
              if(is_array($this->institution)){
                  foreach ($this->institution as $value){
                      $query->orFilterWhere(['=', 'institution', $value]);
                  }
              }else{
                  $query->andFilterWhere(['=', 'institution', $this->institution]);
              }
          }

          $query->andFilterWhere([
              'id' => $this->id,
          ]);

          $query->andFilterWhere(['like', 'process_code', $this->process_code])
              ->andFilterWhere(['like', 'created_by', $this->created_by])
              ->andFilterWhere(['like', 'updated_by', $this->updated_by])
              ->andFilterWhere(['like', 'event_code', $this->event_code])
              ->andFilterWhere(['like', 'event_desc', $this->event_desc])
              ->andFilterWhere(['like', 'mail_list', $this->mail_list])
              ->andFilterWhere(['like', 'from_list', $this->from_list]);

          if(!empty($this->updated_at)){
              $START_DATE = substr($this->updated_at, 0, 10);
              $END_DATE = substr($this->updated_at, 13);
              $query->andFilterWhere(['between', $this->tableName().'.updated_at', $START_DATE.' 00:00:00', $END_DATE.' 23:59:59']);
          }

        } catch (Exception $e) {
            Yii::$app->session->setFlash('error', 'Exeception capture: ' .  $e->getMessage());
        }

        return $dataProvider;
    }
}
