<?php

namespace app\controllers;

use Yii;
use app\models\ConfigService;
use app\models\searchs\ConfigService as ConfigServiceSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use lo\modules\noty\exceptions\NotyFlashException;
use lo\modules\noty\exceptions\NotyErrorException;
use app\models\Utility;

/**
 * ConfigServiceController implements the CRUD actions for ConfigService model.
 */
class ConfigServiceController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
            ],
        ];
    }

    /**
     * Lists all ConfigService models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ConfigServiceSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $institutions = Utility::getInstitutions();

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'institutions' => $institutions,
        ]);
    }

    /**
     * Displays a single ConfigService model.
     * @param string $INTG_NAME
     * @param string $KEY
     * @param string $INSTITUTION
     * @return mixed
     */
    public function actionView($INTG_NAME, $KEY)
    {
        return $this->render('view', [
            'model' => $this->findModel($INTG_NAME, $KEY),
        ]);
    }

    /**
     * Creates a new ConfigService model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new ConfigService();
        $institutions = Utility::getInstitutions();

        if(Yii::$app->request->post()) {
          $model->load(Yii::$app->request->post());
          $model->CREATED_BY = Yii::$app->user->identity->username;
          $model->LAST_MODIFIED_BY = Yii::$app->user->identity->username;
          if ($model->save()) {
              Yii::$app->session->setFlash('success', 'Created with successful.');
              return $this->redirect(['view', 'INTG_NAME' => $model->INTG_NAME, 'KEY' => $model->KEY]);
          }else{
            Yii::$app->session->setFlash('error', $model->getErrors());
            return $this->render('create', [
                'model' => $model,
                'institutions' => $institutions,
            ]);
          }
        } else {
            return $this->render('create', [
                'model' => $model,
                'institutions' => $institutions,
            ]);
        }
    }

    /**
     * Updates an existing ConfigService model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $INTG_NAME
     * @param string $KEY
     * @param string $INSTITUTION
     * @return mixed
     */
    public function actionUpdate($INTG_NAME, $KEY)
    {
        $model = $this->findModel($INTG_NAME, $KEY);
        $institutions = Utility::getInstitutions();

        if ($model->load(Yii::$app->request->post()))
        {
          $model->LAST_MODIFIED_BY = Yii::$app->user->identity->username;
          if ($model->save()) {
              Yii::$app->session->setFlash('success', 'Updated with successful.');
              return $this->redirect(['view', 'INTG_NAME' => $model->INTG_NAME, 'KEY' => $model->KEY]);
          }
        } else {
            return $this->render('update', [
                'model' => $model,
                'institutions' => $institutions
            ]);
        }
    }

    /**
     * Deletes an existing ConfigService model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $INTG_NAME
     * @param string $KEY
     * @param string $INSTITUTION
     * @return mixed
     */
    public function actionDelete($INTG_NAME, $KEY)
    {
        $model = $this->findModel($INTG_NAME, $KEY);
        if($model->STATUS == 'I')
        {
          $model->STATUS = 'A';
        }else{
          $model->STATUS = 'I';
        }
        if($model->save()) {
            Yii::$app->session->setFlash('success', 'Status changed with successful.');
        }
        return $this->redirect(['index']);
    }

    /**
     * Finds the ConfigService model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $INTG_NAME
     * @param string $KEY
     * @param string $INSTITUTION
     * @return ConfigService the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($INTG_NAME, $KEY)
    {
        if (($model = ConfigService::findOne(['INTG_NAME' => $INTG_NAME, 'KEY' => $KEY])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function findModelByKey($KEY)
    {
        if (($model = ConfigService::findOne(['KEY' => $KEY])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionDisabledbulk(){
      $selection=(array)Yii::$app->request->post('selection');
      if(count($selection) > 0){
        foreach($selection as $KEY){
          $model = $this->findModelByKey($KEY);
          $model->STATUS = 'I';
          if(!$model->save()){
              Yii::$app->session->setFlash('error', 'An error occurred while executing.');
              return $this->redirect(['index']);
          }
        }
        Yii::$app->session->setFlash('success', 'Datas disabled with successful.');
        return $this->redirect(['index']);
      }
    }

    public function actionActivebulk(){
      $selection=(array)Yii::$app->request->post('selection');
      if(count($selection) > 0){
        foreach($selection as $KEY){
          $model = $this->findModelByKey($KEY);
          $model->STATUS = 'A';
          if(!$model->save()){
              Yii::$app->session->setFlash('error', 'An error occurred while executing.');
              return $this->redirect(['index']);
          }
        }
        Yii::$app->session->setFlash('success', 'Datas enabled with successful.');
        return $this->redirect(['index']);
      }
    }
}
