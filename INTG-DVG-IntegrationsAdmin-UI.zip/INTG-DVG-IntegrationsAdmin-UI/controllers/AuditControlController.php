<?php

namespace app\controllers;

use Yii;
use app\models\AuditControl;
use app\models\searchs\AuditControl as AuditControlSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Utility;
use yii\data\Pagination;
use yii\base\ErrorException;
use lo\modules\noty\exceptions\NotyFlashException;
use lo\modules\noty\exceptions\NotyErrorException;

/**
 * IntegrationController implements the CRUD actions for Integration model.
 */
class AuditControlController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Integration models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new AuditControlSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $institutions = Utility::getInstitutions();

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'institutions' => $institutions
        ]);
    }

    /**
     * Displays a single Integration model.
     * @param string $INSTITUTION
     * @param string $INTEGRATION
     * @return mixed
     */
    public function actionView($INSTITUTION, $INTEGRATION)
    {
        return $this->render('view', [
            'model' => $this->findModel($INSTITUTION, $INTEGRATION),
        ]);
    }

    /**
     * Creates a new Integration model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new AuditControl();
        $institutions = Utility::getInstitutions();

        try {
          if(Yii::$app->request->post()) {
            $model->load(Yii::$app->request->post());
            $model->CREATED_BY = Yii::$app->user->identity->username;
            if($model->save()) {
              Yii::$app->session->setFlash('success', 'Created with successful.');
              return $this->redirect(['view', 'INSTITUTION' => $model->INSTITUTION, 'INTEGRATION' => $model->INTEGRATION]);
            } else {
              echo "<pre>";
              var_dump($model);exit;
            }
          }else {
            return $this->render('create', [
                'model' => $model,
                'institutions' => $institutions,
            ]);
          }
        } catch (Exception $e) {
          echo "<pre>";
          print_r($e->getMessage());exit;
        }
    }

    /**
     * Updates an existing Integration model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $INSTITUTION
     * @param string $INTEGRATION
     * @return mixed
     */
    public function actionUpdate($INSTITUTION, $INTEGRATION)
    {
        $model = $this->findModel($INSTITUTION, $INTEGRATION);
        $institutions = Utility::getInstitutions();
        try {
          if ($model->load(Yii::$app->request->post()) && $model->validate() ) {
             if($model->save())
             {
               return $this->redirect(['view', 'INSTITUTION' => $model->INSTITUTION, 'INTEGRATION' => $model->INTEGRATION]);
             }
          } else {
            return $this->render('update', [
                'model' => $model,
                'institutions' => $institutions
            ]);
          }
        } catch (\yii\db\Exception $e) {
          Yii::$app->session->setFlash('error', $e->errorInfo[2]);
          return $this->render('update', [
              'model' => $model,
              'institutions' => $institutions
          ]);
        }
    }

    /**
     * Deletes an existing Integration model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $INSTITUTION
     * @param string $INTEGRATION
     * @return mixed
     */
    public function actionDelete($INSTITUTION, $INTEGRATION)
    {
        $this->findModel($INSTITUTION, $INTEGRATION)->delete();
        return $this->redirect(['index']);
    }

    /**
     * Finds the Integration model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $INSTITUTION
     * @param string $INTEGRATION
     * @return Integration the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($INSTITUTION, $INTEGRATION)
    {
        if (($model = AuditControl::findOne(['INSTITUTION' => $INSTITUTION, 'INTEGRATION' => $INTEGRATION])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionReprocess()
    {
      try {
        $obj = (object)Yii::$app->request->post();
        $model = $this->findModel($obj->INSTITUTION, $obj->INTEGRATION);
        $model->REPROCESS == 'N' ? $model->REPROCESS = 'Y' : $model->REPROCESS = 'N';
        $model->save();
      } catch (Exception $e) {
        echo "<pre>";
        var_dump($e->getMessage());exit;
      }
    }

    public function actionEnablereprocessbulk(){
      $selection=(array)Yii::$app->request->post('selection');
      if(count($selection) > 0){
        foreach($selection as $INTEGRATION){
          try {
            Yii::$app->db->createCommand()
                         ->update(AuditControlSearch::tableName(), ['REPROCESS' => 'Y'], 'INTEGRATION ="'.$INTEGRATION.'"')
                         ->execute();
          } catch (Exception $e) {
            echo "<pre>";
            var_dump($e->getMessage());exit;
              return $e->getMessage();
          }
        }
        Yii::$app->session->setFlash('success', 'Resubmit enabled with successfully.');
        return $this->redirect(['index']);
      }
    }

    public function actionDisablereprocessbulk()
    {
      $selection=(array)Yii::$app->request->post('selection');
      if(count($selection) > 0){
        foreach($selection as $INTEGRATION){
          try {
            Yii::$app->db->createCommand()
                         ->update(AuditControlSearch::tableName(), ['REPROCESS' => 'N'], 'INTEGRATION ="'.$INTEGRATION.'"')
                         ->execute();
          } catch (Exception $e) {
            echo "<pre>";
            var_dump($e->getMessage());exit;
              return $e->getMessage();
          }
        }
        Yii::$app->session->setFlash('success', 'Resubmit disabled with successfully.');
        return $this->redirect(['index']);
      }
    }
}
