<?php

namespace app\controllers;

use Yii;
use app\models\Audit;
use app\models\AuditDetail;
use app\models\searchs\Audit as AuditSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\httpclient\Client;
use app\models\Utility;


/**
 * AuditController implements the CRUD actions for Audit model.
 */
class AuditController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Audit models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new AuditSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $institutions = Utility::getInstitutions();

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'institutions' => $institutions,
        ]);
    }

    /**
     * Displays a single Audit model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Audit model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Audit();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->ID]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Finds the Audit model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Audit the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Audit::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionPayload($id)
    {
        $model = AuditDetail::findOne($id);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        } else {
          return $this->renderAjax('payload', ['model' => $model]);
        }
    }

    public function actionResubmitnow(){
        $form=(array)Yii::$app->request->post();
        $model = AuditDetail::findOne($form['AuditDetail']['ID']);
        $model->load(Yii::$app->request->post());
        try {
          if($model->save()){
              $client = new Client();
              $response = $client->createRequest()
                  ->setMethod('POST')
                  ->setUrl('http://10.158.228.80:8280/reprocessMsg')
                  ->setData(['id' => $model->ID])
                  ->send();
          }
        } catch (Exception $e) {
          return $e->getMessage();
        }
    }

    public function actionBuilkresubmitnow(){
      $selection=(array)Yii::$app->request->post('selection');
      $client = new Client();
      if(count($selection) > 0){
        foreach($selection as $id){
          try {
            $response = $client->createRequest()
                ->setMethod('POST')
                ->setUrl('http://10.158.228.80:8280/reprocessMsg')
                ->setData(['id' => $id])
                ->send();
          } catch (Exception $e) {
              return $e->getMessage();
          }
        }
      }
    }
}
