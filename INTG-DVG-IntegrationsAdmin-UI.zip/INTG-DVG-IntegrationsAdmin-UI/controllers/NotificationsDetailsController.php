<?php

namespace app\controllers;

use Yii;
use app\models\NotificationsDetails;
use app\models\searchs\NotificationsDetails as NotificationsDetailsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use lo\modules\noty\exceptions\NotyFlashException;
use lo\modules\noty\exceptions\NotyErrorException;
use app\models\Utility;

/**
 * NotificationsDetailsController implements the CRUD actions for NotificationsDetails model.
 */
class NotificationsDetailsController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all NotificationsDetails models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new NotificationsDetailsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $institutions = Utility::getInstitutions();

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'institutions' => $institutions,
        ]);
    }

    /**
     * Displays a single NotificationsDetails model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new NotificationsDetails model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new NotificationsDetails();
        $institutions = Utility::getInstitutions();

        if(Yii::$app->request->post()) {
          $model->load(Yii::$app->request->post());
          $model->created_by = Yii::$app->user->identity->username;
          $model->updated_by = Yii::$app->user->identity->username;
          if($model->save()) {
            Yii::$app->session->setFlash('success', 'Created with successful.');
            return $this->redirect(['view', 'id' => $model->id]);
          }
        }else {
          return $this->render('create', [
              'model' => $model,
              'institutions' => $institutions,
          ]);
        }
    }

    /**
     * Updates an existing NotificationsDetails model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        $model->updated_by = Yii::$app->user->identity->username;
        $model->updated_at = date('Y-m-d H:m:s');
        $institutions = Utility::getInstitutions();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Updated with successful.');
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
                'institutions' => $institutions
            ]);
        }
    }

    /**
     * Deletes an existing NotificationsDetails model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        return $this->redirect(['index']);
    }

    /**
     * Finds the NotificationsDetails model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return NotificationsDetails the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = NotificationsDetails::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionBulk(){
      $selection=(array)Yii::$app->request->post('selection');
      if(count($selection) > 0){
        foreach($selection as $id){
          $this->findModel($id)->delete();
        }
        Yii::$app->session->setFlash('success', 'Data delete with successful.');
      }else{
          Yii::$app->session->setFlash('error', 'No data has been selected to be deleted.');
      }
      return $this->redirect(['index']);
    }
}
