<?php

namespace app\controllers;

use Yii;
use app\models\Audit;
use app\models\AuditDetail;
use app\models\AuditArchive;
use app\models\AuditDetailArchive;
use app\models\searchs\AuditArchive as AuditArchiveSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Utility;

/**
 * AuditArchiveController implements the CRUD actions for AuditArchive model.
 */
class AuditArchiveController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all AuditArchive models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new AuditArchiveSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $institutions = Utility::getInstitutions();

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'institutions' => $institutions,
        ]);
    }

    /**
     * Displays a single AuditArchive model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new AuditArchive model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new AuditArchive();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->ID]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing AuditArchive model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->ID]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing AuditArchive model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        return $this->redirect(['index']);
    }

    /**
     * Finds the AuditArchive model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return AuditArchive the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = AuditArchive::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionSendcurrentdatabase($id)
    {
      try {
        $auditArchive = $this->findModel($id);
        $auditDetailArchive = $auditArchive->auditDetail;

        $audit = new Audit();
        $auditDetail = new AuditDetail();

        /* Set values to audit and save. If saved, delete auditArchive */
        foreach ($auditArchive as $key => $value) {
          $audit->$key = $value;
        }
        $audit->STATUS = 'R';
        $audit->ERROR_CODE = (string)1;
        if ($audit->save() && $auditArchive->delete() && !empty($auditDetailArchive))
        {
          /* Set values to auditDetail and save. If saved, delete auditDetailArchive */
          foreach ($auditDetailArchive as $key => $value) {
            $auditDetail->$key = $value;
          }
          $auditDetail->save() && $auditDetailArchive->delete();
        }
        Yii::$app->session->setFlash('success', 'Data send to current database with successful.');
        return $this->redirect(['index']);
      } catch (Exception $e) {
        Yii::$app->session->setFlash('error', $e->getMessage());
        return $this->redirect(['index']);
      }
    }

    public function actionBulk()
    {
      $selection=(array)Yii::$app->request->post('selection');
      try {
        if(count($selection) > 0){
          foreach($selection as $id){
            $auditArchive = $this->findModel($id);
            $auditDetailArchive = $auditArchive->auditDetail;

            $audit = new Audit();
            $auditDetail = new AuditDetail();

            /* Set values to audit and save. If saved, delete auditArchive */
            foreach ($auditArchive as $key => $value) {
              $audit->$key = $value;
            }

            $audit->STATUS = 'R';
            $audit->ERROR_CODE = (string)1;

            if ($audit->save() && $auditArchive->delete() && !empty($auditDetailArchive)) {
              /* Set values to auditDetail and save. If saved, delete auditDetailArchive */
              foreach ($auditDetailArchive as $key => $value) {
                $auditDetail->$key = $value;
              }
              $auditDetail->save() && $auditDetailArchive->delete();
            }
            Yii::$app->session->setFlash('success', 'Data delete with successful.');
            return $this->redirect(['index']);
          }
        }
      } catch (Exception $e) {
        Yii::$app->session->setFlash('error', $e->getMessage());
        return $this->redirect(['index']);
      }
    }
}
