<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'jRFExE7Ma7iFr_VUalPlkOuIyByjZL-k',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
          'identityClass' => 'mdm\admin\models\User',
          'loginUrl' => ['admin/user/login'],
          'enableAutoLogin' => false,
          'authTimeout' => 600,
        ],
        'authManager' => [
            'class' => 'yii\rbac\DbManager', // or use 'yii\rbac\DbManager'
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'useFileTransport' => true,
            'messageConfig' => [
                'from' => ['igor.moura@ifactory.com.br' => 'Admin'], // this is needed for sending emails
                'charset' => 'UTF-8',
            ]
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'view'=> [
          'theme' => [
            'pathMap' => [
                '@vendor/mdmsoft/yii2-admin/views/user' => '@app/views/user', // Override
                '@vendor/mdmsoft/yii2-admin/views/assignment' => '@app/views/assignment', // Override
            ],
          ],
        ],
        'db' => require(__DIR__ . '/databases/db.php'),
        'db_archives' => require(__DIR__ . '/databases/db_archives.php'),
        'urlManager' => [
          'class' => 'yii\web\UrlManager',
          'showScriptName' => false,
          'enablePrettyUrl' => true,
          'rules' => array(
                  '<controller:\w+>/<id:\d+>' => '<controller>/view',
                  '<controller:\w+>/<action:\w+>/<id:\d+>' => '<controller>/<action>',
                  '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
          ),
        ],
    ],
    'modules' => [
        'admin' => [
            'class' => 'mdm\admin\Module',
            'mainLayout' => '@app/views/layouts/main.php',
            'controllerMap' => [
                'assignment' => [
                    'class' => 'mdm\admin\controllers\AssignmentController',
                    'userClassName' => 'mdm\admin\models\User',
                    'idField' => 'user_id',
                    'usernameField' => 'username',
                    'extraColumns' => [
                        [
                            'attribute' => 'email',
                            'label' => 'Email',
                            'value' => function($model, $key, $index, $column) {
                                return $model->email;
                            },
                        ],
                        [
                            'attribute' => 'status',
                            'label' => 'Status',
                            'content'=> function($data){
                              return $data->status=10?'<span class="label label-success">Active</span>':'<span class="label label-danger">Inactive</span>';
                            },
                            'filter'=>array("10"=>"Active","0"=>"Inactive"),
                        ],
                        [
                            'attribute' => 'created_at',
                            'label' => 'Created At',
                            'value' => function($model, $key, $index, $column) {
                                return Yii::$app->formatter->asDate($model->created_at, 'MM/dd/yyyy');
                            },
                        ],
                    ],
                    'searchClass' => 'mdm\admin\models\searchs\User'
                ],
                'role' => [
                    'class' => 'app\controllers\RoleController',
                ]
            ],
        ],
        'gridview' =>  [
            'class' => '\kartik\grid\Module'
            // enter optional module parameters below - only if you need to
            // use your own export download action or custom translation
            // message source
            // 'downloadAction' => 'gridview/export/download',
            // 'i18n' => []
        ]
    ],
    'as access' => [
        'class' => 'mdm\admin\components\AccessControl',
        'allowActions' => [
            'site/*',
            // The actions listed here will be allowed to everyone including guests.
            // So, 'admin/*' should not appear here in the production, of course.
            // But in the earlier stages of your development, you may probably want to
            // add a lot of actions here until you finally completed setting up rbac,
            // otherwise you may not even take a first step.
        ]
    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];
}

return $config;
