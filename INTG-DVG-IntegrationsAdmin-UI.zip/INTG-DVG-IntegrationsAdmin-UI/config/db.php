<?php

// Configuration database of development
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=intgwso2int.cqgowjzwcafp.us-east-2.rds.amazonaws.com;dbname=dvg',
    'username' => 'dvg-admin',
    'password' => 'evv3cVjQp0ziG0xJT79v',
    'charset' => 'utf8',
];
