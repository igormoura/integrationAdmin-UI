<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=intgwso2dev.cqgowjzwcafp.us-east-2.rds.amazonaws.com;dbname=dvg_archive',
    'username' => 'dvg-arch-admin',
    'password' => 'evv3cVjQp0ziG0xJT79v',
    'charset' => 'utf8',
];
