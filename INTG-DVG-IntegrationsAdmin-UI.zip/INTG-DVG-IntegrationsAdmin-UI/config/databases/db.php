<?php

// return [
//     'class' => 'yii\db\Connection',
//     'dsn' => 'mysql:host=localhost;dbname=dvg',
//     'username' => 'root',
//     'password' => 'mysql',
//     'charset' => 'utf8',
// ];

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=intgwso2dev.cqgowjzwcafp.us-east-2.rds.amazonaws.com;dbname=dvg',
    'username' => 'dvg-admin',
    'password' => 'evv3cVjQp0ziG0xJT79v',
    'charset' => 'utf8',
];
