Integration Admin - UI
============================

WSO2 integration management system.

The system contains:
- `User authetication.`
- `Access control.`
- `Audit View table with resubmit de data.`
- `Audit Archive table with resend data to current database.`
- `Audit Control table with enable or disable data to reprocess.`
- `Configuration service table with changed of status to active or inactive.`
- `Notification Details table.`

DIRECTORY STRUCTURE
-------------------

      assets/             contains assets definition
      commands/           contains console commands (controllers)
      config/             contains application configurations
      controllers/        contains Web controller classes
      mail/               contains view files for e-mails
      models/             contains model classes
      runtime/            contains files generated during runtime
      tests/              contains various tests for the basic application
      vendor/             contains dependent 3rd-party packages
      views/              contains view files for the Web application
      web/                contains the entry script and Web resources


REQUIREMENTS
------------

The minimum requirement by this system that your Web server supports PHP 5.4.0.


INSTALLATION
------------

### Install via git

You can then install this system using the following command:

~~~
git clone https://git-codecommit.us-east-2.amazonaws.com/v1/repos/INTG-DVG-IntegrationsAdmin-UI
cd ./INTG-DVG-IntegrationsAdmin-UI
~~~

Now you should be able to access the application through the following URL, assuming `basic` is the directory
directly under the Web root.

~~~
http://localhost/INTG-DVG-IntegrationsAdmin-UI/web/
~~~


CONFIGURATION
-------------

### Database

Edit the file `config/db.php` with real data, for example:

```php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=DVG',
    'username' => 'root',
    'password' => '123456',
    'charset' => 'utf8',
];
```

### Running  application

1. Start web server:

    ```
    cd root/directory-path/INTG-DVG-IntegrationsAdmin-UI
    $ php yii serve
    ```
