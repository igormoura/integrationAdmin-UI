<?php 

namespace app\rbac;

use yii;
use yii\rbac\Rule;
use yii\db\Query;
use app\controllers\NotificationDetailsController;
use app\models\NotificationsDetails;
/**
 * Checks if authorID matches user passed via params
 */
class ValidGroupRule extends Rule
{
    public $name = 'ValidGroup';
    public $return = [];

    /**
     * @param string|int $user the user ID.
     * @param Item $item the role or permission that this rule is associated with
     * @param array $params parameters passed to ManagerInterface::checkAccess().
     * @return bool a value indicating whether the rule permits the role or permission it is associated with.
     */
    public function execute($user, $item, $params)
    {
        // capturar os grupos pertencentes do usuário

        if(in_array(Yii::$app->controller->action->id, array('view' , 'update'))){
            $query = new Query;
            $query->select('item_name')
                    ->from('auth_assignment')
                    ->where(['user_id' => $user])
                    ->all();
            $res = $query->all();
            foreach ($res as $group) {
                $groups[]=$group['item_name'];
            }

            $pieces = explode("-", Yii::$app->controller->id);
            $modelName = "\app\models\\";
            foreach ($pieces as $value) {
                $modelName .= ucfirst($value);
            }
            $model = new $modelName;        
            $data = $model::find()->where($params)->one();

            if(isset($data['INSTITUTION'])){
                if(!in_array($data['INSTITUTION'], $groups)){
                    return false;
                }
            } else {
                if(!in_array($data['institution'], $groups)){
                    return false;
                }
            }
        }
        return true;
    }
}